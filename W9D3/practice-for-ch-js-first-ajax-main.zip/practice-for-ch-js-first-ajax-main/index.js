console.log("Hello from the console!");

// Your code here